package com.studentfeemanagementsystem.feesmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeesmanagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
