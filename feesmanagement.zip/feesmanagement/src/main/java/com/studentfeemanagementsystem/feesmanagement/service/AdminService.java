package com.studentfeemanagementsystem.feesmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentfeemanagementsystem.feesmanagement.entities.Admin;
import com.studentfeemanagementsystem.feesmanagement.entities.Student;
import com.studentfeemanagementsystem.feesmanagement.repository.AdminRepository;
import com.studentfeemanagementsystem.feesmanagement.repository.StudentRepository;

@Service
public class AdminService {
	@Autowired
    private AdminRepository adminRepository;

    public Admin signup(Admin admin) {
        return adminRepository.save(admin);
    }

    public Admin signin(String email, String password) {
    	Admin admin = adminRepository.findByEmail(email);
        if (admin != null && admin.getPassword().equals(password)) {
            return admin;
        }
        
        return null;
    }
}
