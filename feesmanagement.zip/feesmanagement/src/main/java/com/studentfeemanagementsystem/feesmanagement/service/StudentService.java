package com.studentfeemanagementsystem.feesmanagement.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.studentfeemanagementsystem.feesmanagement.entities.Student;
import com.studentfeemanagementsystem.feesmanagement.repository.StudentRepository;
@Service
public class StudentService {
	@Autowired
    private StudentRepository studentRepository;

    public Student signup(Student student) {
        return studentRepository.save(student);
    }

    public Student signin(String email, String password) {
        Student student = studentRepository.findByEmail(email);
        if (student != null && student.getPassword().equals(password)) {
            return student;
        }
        
        return null;
    }
    
    public Student updateStudent(Long rollnumber, Student updatedStudent) {
        Optional<Student> existingStudentOptional = studentRepository.findById(rollnumber);
        if (existingStudentOptional.isPresent()) {
            Student existingStudent = existingStudentOptional.get();
            // Update the fields of the existing student with the fields from the updated student
            existingStudent.setStudentName(updatedStudent.getStudentName());
            existingStudent.setEmail(updatedStudent.getEmail());
            existingStudent.setBranch(updatedStudent.getBranch());
            existingStudent.setContactNumber(updatedStudent.getContactNumber());
            existingStudent.setAddress(updatedStudent.getAddress());
            // Save the updated student
            return studentRepository.save(existingStudent);
        } else {
            // Student with the given roll number not found
            throw new IllegalArgumentException("Student not found with roll number: " + rollnumber);
        }
    }

    public void deleteStudent(Long rollnumber) {
        studentRepository.deleteById(rollnumber);
    }

//	public void deleteStudent(Long rollnumber) {
//		// TODO Auto-generated method stub
//		
//	}
}
