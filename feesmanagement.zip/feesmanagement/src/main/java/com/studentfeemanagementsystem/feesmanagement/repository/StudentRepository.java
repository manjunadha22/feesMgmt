package com.studentfeemanagementsystem.feesmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentfeemanagementsystem.feesmanagement.entities.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {
	Student findByEmail(String email);
	Student findByRollnumber(Long rollnumber);
}
