package com.studentfeemanagementsystem.feesmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentfeemanagementsystem.feesmanagement.entities.Fees;
import com.studentfeemanagementsystem.feesmanagement.repository.FeesRepository;

@RestController
public class FeesController {
	
	@Autowired
	private FeesRepository repo;
	
	@PostMapping("/getFees/{deptName}")
	public Fees findByDept(@PathVariable("deptName") String deptName) {
		Fees fees = repo.findByDeptName(deptName);
		return fees;
	}

}
