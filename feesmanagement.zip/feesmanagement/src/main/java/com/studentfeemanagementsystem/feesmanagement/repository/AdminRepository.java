package com.studentfeemanagementsystem.feesmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentfeemanagementsystem.feesmanagement.entities.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer>{

	Admin findByEmail(String email);
	
}
