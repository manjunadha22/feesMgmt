package com.studentfeemanagementsystem.feesmanagement.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Admin {

	@Id
	private long empld;
	private String empName;
	@Column(unique = true)
	private String email;
	private String password;
	private long contactNumber;
	private String address;

	public Admin(Long empld, String empName, String email, String password, Long contactNumber, String address) {
		super();
		this.empld = empld;
		this.empName = empName;
		this.email = email;
		this.password = password;
		this.contactNumber = contactNumber;
		this.address = address;
	}

	public Admin() {
		super();
	}

	public Long getEmpld() {
		return empld;
	}

	public void setEmpld(Long empld) {
		this.empld = empld;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

}
