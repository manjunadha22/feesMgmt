package com.studentfeemanagementsystem.feesmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.studentfeemanagementsystem.feesmanagement.entities.Fees;

public interface FeesRepository extends JpaRepository<Fees, String> {
	Fees findByDeptName(String deptName);
}
