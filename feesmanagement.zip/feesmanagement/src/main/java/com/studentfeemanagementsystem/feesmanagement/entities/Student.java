package com.studentfeemanagementsystem.feesmanagement.entities;



import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
	
	@Id
	private Long rollnumber;
	private String studentName;
	private String department;
	private int semester;
	@Column(unique=true)
	private String email;
	private String password;
	private String branch; 
	private Long contactNumber;
	private String address;
	private float tutionFees=15000;
	private float examFees = 1200;
	private int paidAmountOfTutionFees;
	private int paidAmountOfExamFees;
	private float dueOfTutionFees=15000;
	private float dueOfExamFees=1200;
	private String paymentStatus = "not paid";
	private String paidDate="-";
	
	public Student(Long rollnumber, String studentName, String department, int semester, String email, String password,
			String branch, Long contactNumber, String address, float tutionFees, float examFees,
			int paidAmountOfTutionFees, int paidAmountOfExamFees, float dueOfTutionFees, float dueOfExamFees,
			String paymentStatus, String paidDate) {
		super();
		this.rollnumber = rollnumber;
		this.studentName = studentName;
		this.department = department;
		this.semester = semester;
		this.email = email;
		this.password = password;
		this.branch = branch;
		this.contactNumber = contactNumber;
		this.address = address;
		this.tutionFees = tutionFees;
		this.examFees = examFees;
		this.paidAmountOfTutionFees = paidAmountOfTutionFees;
		this.paidAmountOfExamFees = paidAmountOfExamFees;
		this.dueOfTutionFees = dueOfTutionFees;
		this.dueOfExamFees = dueOfExamFees;
		this.paymentStatus = paymentStatus;
		this.paidDate = paidDate;
	}
	
	public int getPaidAmountOfTutionFees() {
		return paidAmountOfTutionFees;
	}
	public void setPaidAmountOfTutionFees(int paidAmountOfTutionFees) {
		this.paidAmountOfTutionFees = paidAmountOfTutionFees;
	}
	public int getPaidAmountOfExamFees() {
		return paidAmountOfExamFees;
	}
	public void setPaidAmountOfExamFees(int paidAmountOfExamFees) {
		this.paidAmountOfExamFees = paidAmountOfExamFees;
	}
	public float getDueOfTutionFees() {
		return dueOfTutionFees;
	}
	public void setDueOfTutionFees(float dueOfTutionFees) {
		this.dueOfTutionFees = dueOfTutionFees;
	}
	public float getDueOfExamFees() {
		return dueOfExamFees;
	}
	public void setDueOfExamFees(float dueOfExamFees) {
		this.dueOfExamFees = dueOfExamFees;
	}
	public float getTutionFees() {
		return tutionFees;
	}
	public void setTutionFees(float tutionFees) {
		this.tutionFees = tutionFees;
	}
	public float getExamFees() {
		return examFees;
	}
	public void setExamFees(float examFees) {
		this.examFees = examFees;
	}
	public Long getRollnumber() {
		return rollnumber;
	}
	public void setRollnumber (Long rollnumber) {
		this.rollnumber = rollnumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public Long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber (Long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getPaidDate() {
		return paidDate;
	}
	public void setPaidDate(String paidDate) {
		this.paidDate = paidDate;
	}
	public Student() {
		super();
	}

}
