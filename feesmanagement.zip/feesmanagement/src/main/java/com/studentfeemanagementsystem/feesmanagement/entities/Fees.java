package com.studentfeemanagementsystem.feesmanagement.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Fees {
	@Id
	private String deptName;
	private int semester;
	private float tutionfees = 15000;
	private float examfees = 1200;
	public Fees(String deptName, int semester, float tutionfees, float examfees) {
		super();
		this.deptName = deptName;
		this.semester = semester;
		this.tutionfees = tutionfees;
		this.examfees = examfees;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public float getTutionfees() {
		return tutionfees;
	}
	public void setTutionfees(float tutionfees) {
		this.tutionfees = tutionfees;
	}
	public float getExamfees() {
		return examfees;
	}
	public void setExamfees(float examfees) {
		this.examfees = examfees;
	}
	public Fees() {
		super();
	}
	
	
	
}
