package com.studentfeemanagementsystem.feesmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.studentfeemanagementsystem.feesmanagement.entities.Admin;
import com.studentfeemanagementsystem.feesmanagement.entities.LoginRequest;
import com.studentfeemanagementsystem.feesmanagement.entities.Student;
import com.studentfeemanagementsystem.feesmanagement.service.AdminService;

@RestController
@RequestMapping("/api/admins")
public class AdminController {
	@Autowired
    private AdminService adminService;

    @PostMapping("/signup")
    public Admin signup(@RequestBody Admin admin) {
    	
        return adminService.signup(admin);
    }

    @PostMapping("/signin")
    public ResponseEntity<?> signin(@RequestBody LoginRequest loginRequest) {
        Admin admin = adminService.signin(loginRequest.getEmail(), loginRequest.getPassword());
        if (admin != null) {
            return ResponseEntity.ok(admin);
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid credentials");
        }
    }
}
