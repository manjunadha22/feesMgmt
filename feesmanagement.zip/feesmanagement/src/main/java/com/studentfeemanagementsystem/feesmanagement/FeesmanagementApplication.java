package com.studentfeemanagementsystem.feesmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FeesmanagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(FeesmanagementApplication.class, args);
	}

}
